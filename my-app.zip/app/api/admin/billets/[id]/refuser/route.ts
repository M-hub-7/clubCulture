import { NextResponse } from "next/server";
import { getUser } from "@/app/lib/getUser";
import { prisma } from "@/app/lib/prisma";
import { stripe } from "@/app/lib/stripe";

export async function POST(
  request: Request,
  { params }: { params: { id: string } },
) {
  try {
    const session = await getUser(request);

    if (!session?.user) {
      return NextResponse.json({ erreur: "Non authentifié." }, { status: 401 });
    }

    const roles = (session.user as any).roles || [];
    const estAdmin = Array.isArray(roles) && roles.includes("ADMIN");

    if (!estAdmin) {
      return NextResponse.json(
        { erreur: "Accès refusé - Rôle ADMIN requis." },
        { status: 403 },
      );
    }

    const billetId = params.id;

    const billet = await prisma.billet.findUnique({
      where: { id: billetId },
      include: { commande: true },
    });

    if (!billet) {
      return NextResponse.json(
        { erreur: "Billet introuvable." },
        { status: 404 },
      );
    }

    // Passage du statut du billet en REFUSE
    await prisma.billet.update({
      where: { id: billet.id },
      data: { statut: "REFUSE" },
    });

    // Mise à jour de la commande
    await prisma.commande.update({
      where: { id: billet.commandeId },
      data: { statut: "REFUSEE" },
    });

    // Remboursement automatique sur Stripe
    if (billet.commande.referencePaiement) {
      try {
        await stripe.refunds.create({
          payment_intent: billet.commande.referencePaiement,
        });
      } catch (stripeErr) {
        console.error("Erreur lors du remboursement Stripe :", stripeErr);
      }
    }

    return NextResponse.json({
      succes: true,
      message: "Billet refusé et remboursement initié.",
    });
  } catch (error) {
    console.error("Erreur POST /api/admin/billets/[id]/refuser :", error);

    return NextResponse.json(
      { erreur: "Erreur serveur lors du refus." },
      { status: 500 },
    );
  }
}
