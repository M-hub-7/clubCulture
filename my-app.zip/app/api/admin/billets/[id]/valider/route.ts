import { NextResponse } from "next/server";
import { getUser } from "@/app/lib/getUser";
import { prisma } from "@/app/lib/prisma";
import { signJwt } from "@/app/lib/qrcode";

export async function POST(
  request: Request,
  { params }: { params: { id: string } },
) {
  try {
    const session = await getUser(request);

    if (!session?.user) {
      return NextResponse.json({ erreur: "Non authentifié." }, { status: 401 });
    }

    const roles = (session.user as any).roles || [];
    const estAdmin = Array.isArray(roles) && roles.includes("ADMIN");

    if (!estAdmin) {
      return NextResponse.json(
        { erreur: "Accès refusé - Rôle ADMIN requis." },
        { status: 403 },
      );
    }

    const billetId = params.id;

    const billet = await prisma.billet.findUnique({
      where: { id: billetId },
      include: {
        commande: {
          include: { acheteur: true },
        },
        categorie: {
          include: { evenement: true },
        },
      },
    });

    if (!billet) {
      return NextResponse.json(
        { erreur: "Billet introuvable." },
        { status: 404 },
      );
    }

    if (billet.statut !== "EN_ATTENTE_VALIDATION") {
      return NextResponse.json(
        { erreur: "Ce billet n'est pas en attente de validation." },
        { status: 400 },
      );
    }

    // Génération du jeton JWT/QR Code cryptographique
    const jetonSignature = await signJwt({
      billetId: billet.id,
      evenementId: billet.categorie.evenementId,
    });

    // Passage du billet en statut VALIDE
    const billetValide = await prisma.billet.update({
      where: { id: billet.id },
      data: {
        statut: "VALIDE",
        jetonSignature,
      },
    });

    // Mise à jour de la commande si tous les billets sont validés
    const billetsRestants = await prisma.billet.count({
      where: {
        commandeId: billet.commandeId,
        statut: "EN_ATTENTE_VALIDATION",
      },
    });

    if (billetsRestants === 0) {
      await prisma.commande.update({
        where: { id: billet.commandeId },
        data: { statut: "PAYEE" },
      });
    }

    return NextResponse.json({
      succes: true,
      message:
        "Billet validé avec succès. Il est désormais disponible dans l'espace de l'utilisateur.",
      billet: billetValide,
    });
  } catch (error) {
    console.error("Erreur POST /api/admin/billets/[id]/valider :", error);

    return NextResponse.json(
      { erreur: "Erreur serveur lors de la validation." },
      { status: 500 },
    );
  }
}
