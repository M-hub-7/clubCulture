import { NextResponse } from "next/server";
import { headers } from "next/headers";
import { stripe } from "@/app/lib/stripe";
import { prisma } from "@/app/lib/prisma";
import Stripe from "stripe";

export async function POST(req: Request) {
  const body = await req.text();
  const signature = (await headers()).get("stripe-signature");

  let event: Stripe.Event;

  try {
    if (!signature || !process.env.STRIPE_WEBHOOK_SECRET) {
      throw new Error("Clé de signature Webhook manquante");
    }
    event = stripe.webhooks.constructEvent(
      body,
      signature,
      process.env.STRIPE_WEBHOOK_SECRET,
    );
  } catch (err: any) {
    console.error(`Webhook signature failed: ${err.message}`);
    return NextResponse.json(
      { error: `Webhook Error: ${err.message}` },
      { status: 400 },
    );
  }

  if (event.type === "checkout.session.completed") {
    const session = event.paymentIntent
      ? await stripe.paymentIntents.retrieve(event.paymentIntent as string)
      : (event.data.object as Stripe.Checkout.Session);

    const commandeId = session.metadata?.commandeId;

    if (commandeId) {
      // 1. Mettre à jour la commande en "EN_ATTENTE_VALIDATION"
      const commande = await prisma.commande.update({
        where: { id: commandeId },
        data: {
          statut: "EN_ATTENTE_VALIDATION",
          referencePaiement: session.id,
        },
        include: { billets: true },
      });

      // 2. Mettre à jour le statut initial des billets associés
      await prisma.billet.updateMany({
        where: { commandeId: commande.id },
        data: { statut: "EN_ATTENTE_VALIDATION" },
      });

      console.log(
        `Commande ${commandeId} payée et en attente de validation admin.`,
      );
    }
  }

  return NextResponse.json({ received: true });
}
