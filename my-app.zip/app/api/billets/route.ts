import { NextResponse } from "next/server";
import { getUser } from "@/app/lib/getUser";
import { prisma } from "@/app/lib/prisma";
import { genererQRCode } from "@/app/lib/qrcode";

export async function GET(request: Request) {
  try {
    const session = await getUser(request);

    if (!session?.user) {
      return NextResponse.json({ erreur: "Non authentifié." }, { status: 401 });
    }

    const { searchParams } = new URL(request.url);

    const evenementId = searchParams.get("evenementId");

    const commandes = await prisma.commande.findMany({
      where: {
        acheteurId: session.user.id,
        // Inclut PAYEE et EN_ATTENTE_VALIDATION
        statut: {
          in: ["PAYEE", "EN_ATTENTE_VALIDATION"],
        },

        ...(evenementId
          ? {
              evenementId,
            }
          : {}),
      },

      include: {
        evenement: {
          include: {
            organisateur: {
              select: {
                nomPublic: true,
              },
            },
          },
        },

        billets: {
          include: {
            categorie: true,
          },
        },
      },

      orderBy: {
        created: "desc",
      },
    });

    const commandesAvecQR = await Promise.all(
      commandes.map(async (commande) => ({
        ...commande,

        billets: await Promise.all(
          commande.billets.map(async (billet) => {
            const tokenOuJeton = billet.jetonSignature || (billet as any).token;

            return {
              ...billet,
              // Le QR code est généré uniquement si le billet est validé par l'admin
              qrCode:
                billet.statut === "VALIDE" && tokenOuJeton
                  ? await genererQRCode(tokenOuJeton)
                  : null,
            };
          }),
        ),
      })),
    );

    return NextResponse.json(commandesAvecQR);
  } catch (error) {
    console.error("Erreur GET /api/billets :", error);

    return NextResponse.json(
      {
        erreur: "Erreur serveur.",
      },
      {
        status: 500,
      },
    );
  }
}
